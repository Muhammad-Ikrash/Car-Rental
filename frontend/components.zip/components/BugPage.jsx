
import "./BugPage.css";


export default function LoadingLogo(){

    return(
        <div className="bug-page" >
            <img src="./bugatti.jpg" alt="Loading..." />
        </div>
    )

}